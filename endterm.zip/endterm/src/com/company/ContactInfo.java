package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.*;
import java.util.Scanner;

public class ContactInfo {
    private static final Connection connection = null;

    public static void ContactInfoes() throws Exception {
    Connection connection = null;
    Statement statement = null;
    Scanner sc = new Scanner(System.in);
    try {
        String url = "jdbc:postgresql://localhost:5432/endterm";
        String username = "postgres";
        String password = "030101501636";
        Class.forName("org.postgresql.Driver");
        connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/endterm","postgres","030101501636");
        connection.setAutoCommit(false);
        statement = connection.createStatement();



        System.out.println("Your Name, please:");
        String name = sc.next();

        System.out.println("Your phone number, please:");
        int ph_number = sc.nextInt();

        connection = DriverManager.getConnection(url, username, password);
        String sql = "INSERT INTO contact_info ( name,phone_number) "
                + "VALUES (?,?);";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, ph_number);
        preparedStatement.execute();

    }catch (Exception ex) {
        System.out.println("Connection failed...");
        System.out.println(ex);

    }
}}
