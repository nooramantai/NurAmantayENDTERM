package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {
//        Connection connection = null;
//        Statement statement = null;


//        try {
//            Class.forName("org.postgresql.Driver");
//            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/endterm","postgres", "030101501636");
//            System.out.println(" Database was successful opened");
//
//            statement = connection.createStatement();
//            String sql = "CREATE TABLE card_info " + "(ID serial," + " full_name TEXT NOT NULL, " + " card_numbers INT NOT NULL, " + " cvv INT NOT NULL)";
//            statement.executeUpdate(sql);
//            statement.close();
//            connection.close();
//        }  catch( Exception e ) {
//            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
//            System.exit(0);
//        }


    }}
