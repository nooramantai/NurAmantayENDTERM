package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class CardInfo {
    private static final Connection connection = null;

    public static void CardInfoes() throws Exception {
        Connection connection = null;
        Statement statement = null;
        Scanner sc = new Scanner(System.in);
        try {
            String url = "jdbc:postgresql://localhost:5432/endterm";
            String username = "postgres";
            String password = "030101501636";
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/endterm","postgres","030101501636");
            connection.setAutoCommit(false);
            statement = connection.createStatement();



            System.out.println("Your Full name, please:");
            String name = sc.next();

            System.out.println("Please write numbers of your card:");
            int c_number = sc.nextInt();

            System.out.println("Please write cvv of your card:");
            int cvv = sc.nextInt();

            connection = DriverManager.getConnection(url, username, password);
            String sql = "INSERT INTO card_info ( full_name,card_numbers, cvv) "
                    + "VALUES (?,?,?);";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, c_number);
            preparedStatement.setInt(3, cvv);
            preparedStatement.execute();

        }
        catch (Exception ex) {
            System.out.println("Connection failed...");
            System.out.println(ex);
        }


    }

}
