package com.company;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.text.*;
public class ChatBot extends JFrame implements ActionListener {
    final String TITLE_OF_PROGRAM = "Delivery of food";
    //sizes and decorations that you can see below
    final int START_LOCATION = 30;
    final int WINDOW_WIDTH = 400;
    final int WINDOW_HEIGHT = 520;
    final String CHB_AI = "AI";
    final String BTN_ENTER = "Enter";

    JTextPane dialogue; // area for dialog
    JCheckBox ai;       // enable/disable AI
    JTextField message; // field for entering messages
    Bot bot;     // chat-bot class (in bot package)
    SimpleAttributeSet botStyle; // style bot text

    public static void main(String[] args) {
        new ChatBot();
    }

    ChatBot() {
        //methods of JFRAME
        setTitle(TITLE_OF_PROGRAM);//open title of program
        setDefaultCloseOperation(EXIT_ON_CLOSE);//determine the end of code, if you tab the x on the above right site
        setBounds(START_LOCATION, START_LOCATION, WINDOW_WIDTH, WINDOW_HEIGHT);//coordinates and sizes of chat that we set above
        // area for dialog
        dialogue = new JTextPane();
        dialogue.setEditable(false);
        dialogue.setContentType("text/html");
        JScrollPane scrollBar = new JScrollPane(dialogue);
        // style for bot messages
        botStyle = new SimpleAttributeSet();
        StyleConstants.setItalic(botStyle, true);
        StyleConstants.setForeground(botStyle, Color.blue);
        //StyleConstants.setAlignment(botStyle, StyleConstants.ALIGN_RIGHT);
        // panel for checkbox, message field and button
        JPanel bp = new JPanel();
        bp.setLayout(new BoxLayout(bp, BoxLayout.X_AXIS));
        ai = new JCheckBox(CHB_AI);
        ai.doClick();//on the left below site of the chat
        message = new JTextField();
        message.addActionListener(this);//place to write message
        JButton enter = new JButton(BTN_ENTER);//
        enter.addActionListener(this);

        // adding all elements to the window
        bp.add(ai);
        bp.add(message);
        bp.add(enter);
        add(BorderLayout.CENTER, scrollBar);
        add(BorderLayout.SOUTH, bp);
        setVisible(true);//add graph window
        bot = new Bot(); // creating bot object
    }


    @Override
    public void actionPerformed(ActionEvent event) {
        if (message.getText().trim().length() > 0) {// if we do not write anything “enter” would not work
            try {
                StyledDocument doc = dialogue.getStyledDocument();
                doc.insertString(doc.getLength(), message.getText() + "\n",
                        new SimpleAttributeSet());//that text go to the panel
                doc.insertString(doc.getLength(),
                        TITLE_OF_PROGRAM.substring(0, 9) +
                                bot.sayInReturn(message.getText(), ai.isSelected()) + "\n",
                        botStyle);
            } catch(Exception e) { }
        }
        message.setText("");
        message.requestFocusInWindow();
    }
}
